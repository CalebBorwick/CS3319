window.onload=function(){
    prepareListener();
}

function prepareListener(){
    var uninum;
    uninum=document.getElementById("officialname");
    uninum.addEventListener("change", getUniNum);
}

function getUniNum(){
    this.form.submit();
}

